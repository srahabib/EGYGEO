from .egygeo import get_coordinates
from .egygeo import get_name
